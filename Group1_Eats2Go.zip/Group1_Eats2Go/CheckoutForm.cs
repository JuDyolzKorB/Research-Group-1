﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace Group1_Eats2Go
{
    public partial class ChckOutForm : MetroForm
    {
        public List<frmHome.Order> Orders { get; private set; }
        public double TotalPrice { get; private set; }
        public ChckOutForm()
        {
            InitializeComponent();
        }

        

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void DisplayOrderDetails()
        {
            
        }

         

        private void CashConfirm_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Paid with CASH!", "Checkout", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void CardConfirm_Click(object sender, EventArgs e)
        {
            CARD_DETAILS carddtl = new CARD_DETAILS();
            this.Hide();
            carddtl.Show();

            this.Show(); MessageBox.Show("Paid with CARD!", "Checkout", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}

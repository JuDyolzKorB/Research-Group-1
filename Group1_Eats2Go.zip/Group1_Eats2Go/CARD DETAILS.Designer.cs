﻿namespace Group1_Eats2Go
{
    partial class CARD_DETAILS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cardnumtxtdtl = new System.Windows.Forms.TextBox();
            this.okbutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cardnumtxtdtl
            // 
            this.cardnumtxtdtl.Location = new System.Drawing.Point(23, 123);
            this.cardnumtxtdtl.Multiline = true;
            this.cardnumtxtdtl.Name = "cardnumtxtdtl";
            this.cardnumtxtdtl.Size = new System.Drawing.Size(319, 42);
            this.cardnumtxtdtl.TabIndex = 0;
            this.cardnumtxtdtl.TextChanged += new System.EventHandler(this.cardnumtxtdtl_TextChanged);
            // 
            // okbutton
            // 
            this.okbutton.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.okbutton.Location = new System.Drawing.Point(371, 112);
            this.okbutton.Name = "okbutton";
            this.okbutton.Size = new System.Drawing.Size(75, 59);
            this.okbutton.TabIndex = 1;
            this.okbutton.Text = "OK";
            this.okbutton.UseVisualStyleBackColor = true;
            this.okbutton.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "ENTER 16 CARD NUMBER:";
            // 
            // CARD_DETAILS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 210);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.okbutton);
            this.Controls.Add(this.cardnumtxtdtl);
            this.Name = "CARD_DETAILS";
            this.Text = "CARD DETAILS";
            this.Load += new System.EventHandler(this.CARD_DETAILS_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox cardnumtxtdtl;
        private System.Windows.Forms.Button okbutton;
        private System.Windows.Forms.Label label1;
    }
}
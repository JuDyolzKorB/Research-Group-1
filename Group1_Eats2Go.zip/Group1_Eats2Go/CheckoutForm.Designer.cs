﻿namespace Group1_Eats2Go
{
    partial class ChckOutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ESTtxtCHk = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.label2 = new System.Windows.Forms.Label();
            this.DisplayOrderDetailschk = new MetroFramework.Controls.MetroGrid();
            this.ordername = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CardConfirm = new MetroFramework.Controls.MetroButton();
            this.CashConfirm = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.DisplayOrderDetailschk)).BeginInit();
            this.SuspendLayout();
            // 
            // ESTtxtCHk
            // 
            this.ESTtxtCHk.Location = new System.Drawing.Point(599, 217);
            this.ESTtxtCHk.Multiline = true;
            this.ESTtxtCHk.Name = "ESTtxtCHk";
            this.ESTtxtCHk.Size = new System.Drawing.Size(249, 94);
            this.ESTtxtCHk.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(595, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "ESTIMATED TOTAL:";
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(599, 518);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(249, 53);
            this.metroButton2.TabIndex = 10;
            this.metroButton2.Text = "CANCEL";
            this.metroButton2.UseSelectable = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 24);
            this.label2.TabIndex = 15;
            this.label2.Text = "ORDER DETAILS:";
            // 
            // DisplayOrderDetailschk
            // 
            this.DisplayOrderDetailschk.AllowUserToAddRows = false;
            this.DisplayOrderDetailschk.AllowUserToResizeRows = false;
            this.DisplayOrderDetailschk.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.DisplayOrderDetailschk.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DisplayOrderDetailschk.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DisplayOrderDetailschk.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DisplayOrderDetailschk.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DisplayOrderDetailschk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DisplayOrderDetailschk.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ordername,
            this.quantity,
            this.price,
            this.total});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DisplayOrderDetailschk.DefaultCellStyle = dataGridViewCellStyle2;
            this.DisplayOrderDetailschk.EnableHeadersVisualStyles = false;
            this.DisplayOrderDetailschk.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.DisplayOrderDetailschk.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.DisplayOrderDetailschk.Location = new System.Drawing.Point(40, 154);
            this.DisplayOrderDetailschk.Name = "DisplayOrderDetailschk";
            this.DisplayOrderDetailschk.ReadOnly = true;
            this.DisplayOrderDetailschk.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DisplayOrderDetailschk.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.DisplayOrderDetailschk.RowHeadersWidth = 51;
            this.DisplayOrderDetailschk.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.DisplayOrderDetailschk.RowTemplate.Height = 24;
            this.DisplayOrderDetailschk.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DisplayOrderDetailschk.Size = new System.Drawing.Size(526, 438);
            this.DisplayOrderDetailschk.TabIndex = 16;
            // 
            // ordername
            // 
            this.ordername.HeaderText = "";
            this.ordername.MinimumWidth = 6;
            this.ordername.Name = "ordername";
            this.ordername.ReadOnly = true;
            this.ordername.Width = 125;
            // 
            // quantity
            // 
            this.quantity.HeaderText = "";
            this.quantity.MinimumWidth = 6;
            this.quantity.Name = "quantity";
            this.quantity.ReadOnly = true;
            this.quantity.Width = 125;
            // 
            // price
            // 
            this.price.HeaderText = "";
            this.price.MinimumWidth = 6;
            this.price.Name = "price";
            this.price.ReadOnly = true;
            this.price.Width = 125;
            // 
            // total
            // 
            this.total.HeaderText = "";
            this.total.MinimumWidth = 6;
            this.total.Name = "total";
            this.total.ReadOnly = true;
            this.total.Width = 125;
            // 
            // CardConfirm
            // 
            this.CardConfirm.Location = new System.Drawing.Point(599, 433);
            this.CardConfirm.Name = "CardConfirm";
            this.CardConfirm.Size = new System.Drawing.Size(249, 53);
            this.CardConfirm.TabIndex = 9;
            this.CardConfirm.Text = "PAY WITH CARD";
            this.CardConfirm.UseSelectable = true;
            this.CardConfirm.Click += new System.EventHandler(this.CardConfirm_Click);
            // 
            // CashConfirm
            // 
            this.CashConfirm.Location = new System.Drawing.Point(599, 349);
            this.CashConfirm.Name = "CashConfirm";
            this.CashConfirm.Size = new System.Drawing.Size(249, 53);
            this.CashConfirm.TabIndex = 17;
            this.CashConfirm.Text = "PAY WITH CASH";
            this.CashConfirm.UseSelectable = true;
            this.CashConfirm.Click += new System.EventHandler(this.CashConfirm_Click);
            // 
            // ChckOutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(937, 656);
            this.Controls.Add(this.CashConfirm);
            this.Controls.Add(this.DisplayOrderDetailschk);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.metroButton2);
            this.Controls.Add(this.CardConfirm);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ESTtxtCHk);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "ChckOutForm";
            this.Style = MetroFramework.MetroColorStyle.Orange;
            this.Text = "CHECKOUT";
            this.Theme = MetroFramework.MetroThemeStyle.Default;
            this.TransparencyKey = System.Drawing.Color.Ivory;
            ((System.ComponentModel.ISupportInitialize)(this.DisplayOrderDetailschk)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ESTtxtCHk;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroButton metroButton2;
        private System.Windows.Forms.Label label2;
        private MetroFramework.Controls.MetroGrid DisplayOrderDetailschk;
        private System.Windows.Forms.DataGridViewTextBoxColumn ordername;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
        private System.Windows.Forms.DataGridViewTextBoxColumn total;
        private MetroFramework.Controls.MetroButton CardConfirm;
        private MetroFramework.Controls.MetroButton CashConfirm;
    }
}
﻿namespace Group1_Eats2Go
{
    partial class frmHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.btnMenuCancel = new MetroFramework.Controls.MetroButton();
            this.tabMenuControl = new MetroFramework.Controls.MetroTabControl();
            this.tabMainCoursePage = new MetroFramework.Controls.MetroTabPage();
            this.btnMenuMainCourseEight = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseSeven = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseSix = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseFive = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseFour = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseThree = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseTwo = new MetroFramework.Controls.MetroButton();
            this.btnMenuMainCourseOne = new MetroFramework.Controls.MetroButton();
            this.tabDrinksPage = new MetroFramework.Controls.MetroTabPage();
            this.btnMenuDrinksSeven = new MetroFramework.Controls.MetroButton();
            this.btnMenuDrinksFive = new MetroFramework.Controls.MetroButton();
            this.btnMenuDrinksFour = new MetroFramework.Controls.MetroButton();
            this.btnMenuDrinksThree = new MetroFramework.Controls.MetroButton();
            this.btnMenuDrinksTwo = new MetroFramework.Controls.MetroButton();
            this.btnMenuDrinksOne = new MetroFramework.Controls.MetroButton();
            this.tabDessertPage = new MetroFramework.Controls.MetroTabPage();
            this.btnMenuDessertFour = new MetroFramework.Controls.MetroButton();
            this.btnMenuDessertThree = new MetroFramework.Controls.MetroButton();
            this.btnMenuDessertTwo = new MetroFramework.Controls.MetroButton();
            this.btnMenuDessertOne = new MetroFramework.Controls.MetroButton();
            this.tabFavoritesPage = new MetroFramework.Controls.MetroTabPage();
            this.btnMenuFavoritesFive = new MetroFramework.Controls.MetroButton();
            this.btnMenuFavoritesFour = new MetroFramework.Controls.MetroButton();
            this.btnMenuFavoritesThree = new MetroFramework.Controls.MetroButton();
            this.btnMenuFavoritesTwo = new MetroFramework.Controls.MetroButton();
            this.btnMenuFavoritesOne = new MetroFramework.Controls.MetroButton();
            this.btnMenuDrinks = new MetroFramework.Controls.MetroButton();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.btnMenuFavorites = new MetroFramework.Controls.MetroButton();
            this.btnMenuDessert = new MetroFramework.Controls.MetroButton();
            this.txtMenuTotal = new MetroFramework.Controls.MetroTextBox();
            this.btnMenuMainCourse = new MetroFramework.Controls.MetroButton();
            this.txtMenuOrder = new MetroFramework.Controls.MetroTextBox();
            this.btnMenuCheckOut = new MetroFramework.Controls.MetroButton();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.dataSalesFood = new MetroFramework.Controls.MetroGrid();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataSalesCustomer = new MetroFramework.Controls.MetroGrid();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSalesSearch = new MetroFramework.Controls.MetroButton();
            this.txtSaleSearch = new MetroFramework.Controls.MetroTextBox();
            this.dataSales = new MetroFramework.Controls.MetroGrid();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.btnTransactionSearch = new MetroFramework.Controls.MetroButton();
            this.txtTransactionSearch = new MetroFramework.Controls.MetroTextBox();
            this.dataTransaction = new MetroFramework.Controls.MetroGrid();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroDateTime1 = new MetroFramework.Controls.MetroDateTime();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            this.tabMenuControl.SuspendLayout();
            this.tabMainCoursePage.SuspendLayout();
            this.tabDrinksPage.SuspendLayout();
            this.tabDessertPage.SuspendLayout();
            this.tabFavoritesPage.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSalesFood)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSalesCustomer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSales)).BeginInit();
            this.metroTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataTransaction)).BeginInit();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Controls.Add(this.metroTabPage3);
            this.metroTabControl1.Location = new System.Drawing.Point(31, 78);
            this.metroTabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(1691, 780);
            this.metroTabControl1.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroTabControl1.TabIndex = 0;
            this.metroTabControl1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.metroTabControl1.UseSelectable = true;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.BackColor = System.Drawing.Color.Orange;
            this.metroTabPage1.Controls.Add(this.btnMenuCancel);
            this.metroTabPage1.Controls.Add(this.tabMenuControl);
            this.metroTabPage1.Controls.Add(this.btnMenuDrinks);
            this.metroTabPage1.Controls.Add(this.metroLabel4);
            this.metroTabPage1.Controls.Add(this.btnMenuFavorites);
            this.metroTabPage1.Controls.Add(this.btnMenuDessert);
            this.metroTabPage1.Controls.Add(this.txtMenuTotal);
            this.metroTabPage1.Controls.Add(this.btnMenuMainCourse);
            this.metroTabPage1.Controls.Add(this.txtMenuOrder);
            this.metroTabPage1.Controls.Add(this.btnMenuCheckOut);
            this.metroTabPage1.Controls.Add(this.metroLabel3);
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 12;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 41);
            this.metroTabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(1683, 735);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "Menu";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 0;
            // 
            // btnMenuCancel
            // 
            this.btnMenuCancel.Location = new System.Drawing.Point(1412, 398);
            this.btnMenuCancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuCancel.Name = "btnMenuCancel";
            this.btnMenuCancel.Size = new System.Drawing.Size(241, 65);
            this.btnMenuCancel.TabIndex = 7;
            this.btnMenuCancel.Text = "Cancel";
            this.btnMenuCancel.UseSelectable = true;
            this.btnMenuCancel.Click += new System.EventHandler(this.btnMenuCancel_Click);
            // 
            // tabMenuControl
            // 
            this.tabMenuControl.Controls.Add(this.tabMainCoursePage);
            this.tabMenuControl.Controls.Add(this.tabDrinksPage);
            this.tabMenuControl.Controls.Add(this.tabDessertPage);
            this.tabMenuControl.Controls.Add(this.tabFavoritesPage);
            this.tabMenuControl.Location = new System.Drawing.Point(0, -50);
            this.tabMenuControl.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabMenuControl.Name = "tabMenuControl";
            this.tabMenuControl.SelectedIndex = 0;
            this.tabMenuControl.Size = new System.Drawing.Size(1321, 543);
            this.tabMenuControl.Style = MetroFramework.MetroColorStyle.Orange;
            this.tabMenuControl.TabIndex = 2;
            this.tabMenuControl.TabStop = false;
            this.tabMenuControl.UseSelectable = true;
            // 
            // tabMainCoursePage
            // 
            this.tabMainCoursePage.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseEight);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseSeven);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseSix);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseFive);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseFour);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseThree);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseTwo);
            this.tabMainCoursePage.Controls.Add(this.btnMenuMainCourseOne);
            this.tabMainCoursePage.HorizontalScrollbarBarColor = true;
            this.tabMainCoursePage.HorizontalScrollbarHighlightOnWheel = false;
            this.tabMainCoursePage.HorizontalScrollbarSize = 12;
            this.tabMainCoursePage.Location = new System.Drawing.Point(4, 38);
            this.tabMainCoursePage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabMainCoursePage.Name = "tabMainCoursePage";
            this.tabMainCoursePage.Size = new System.Drawing.Size(1313, 501);
            this.tabMainCoursePage.TabIndex = 1;
            this.tabMainCoursePage.VerticalScrollbarBarColor = true;
            this.tabMainCoursePage.VerticalScrollbarHighlightOnWheel = false;
            this.tabMainCoursePage.VerticalScrollbarSize = 13;
            // 
            // btnMenuMainCourseEight
            // 
            this.btnMenuMainCourseEight.Location = new System.Drawing.Point(1023, 271);
            this.btnMenuMainCourseEight.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseEight.Name = "btnMenuMainCourseEight";
            this.btnMenuMainCourseEight.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseEight.TabIndex = 16;
            this.btnMenuMainCourseEight.UseSelectable = true;
            this.btnMenuMainCourseEight.Click += new System.EventHandler(this.btnMenuMainCourseEight_Click);
            // 
            // btnMenuMainCourseSeven
            // 
            this.btnMenuMainCourseSeven.Location = new System.Drawing.Point(689, 271);
            this.btnMenuMainCourseSeven.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseSeven.Name = "btnMenuMainCourseSeven";
            this.btnMenuMainCourseSeven.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseSeven.TabIndex = 15;
            this.btnMenuMainCourseSeven.UseSelectable = true;
            this.btnMenuMainCourseSeven.Click += new System.EventHandler(this.btnMenuMainCourseSeven_Click);
            // 
            // btnMenuMainCourseSix
            // 
            this.btnMenuMainCourseSix.Location = new System.Drawing.Point(355, 271);
            this.btnMenuMainCourseSix.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseSix.Name = "btnMenuMainCourseSix";
            this.btnMenuMainCourseSix.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseSix.TabIndex = 14;
            this.btnMenuMainCourseSix.UseSelectable = true;
            this.btnMenuMainCourseSix.Click += new System.EventHandler(this.btnMenuMainCourseSix_Click);
            // 
            // btnMenuMainCourseFive
            // 
            this.btnMenuMainCourseFive.Location = new System.Drawing.Point(20, 271);
            this.btnMenuMainCourseFive.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseFive.Name = "btnMenuMainCourseFive";
            this.btnMenuMainCourseFive.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseFive.TabIndex = 13;
            this.btnMenuMainCourseFive.UseSelectable = true;
            this.btnMenuMainCourseFive.Click += new System.EventHandler(this.btnMenuMainCourseFive_Click);
            // 
            // btnMenuMainCourseFour
            // 
            this.btnMenuMainCourseFour.Location = new System.Drawing.Point(1023, 22);
            this.btnMenuMainCourseFour.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseFour.Name = "btnMenuMainCourseFour";
            this.btnMenuMainCourseFour.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseFour.TabIndex = 8;
            this.btnMenuMainCourseFour.UseSelectable = true;
            this.btnMenuMainCourseFour.Click += new System.EventHandler(this.btnMenuMainCourseFour_Click);
            // 
            // btnMenuMainCourseThree
            // 
            this.btnMenuMainCourseThree.Location = new System.Drawing.Point(689, 22);
            this.btnMenuMainCourseThree.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseThree.Name = "btnMenuMainCourseThree";
            this.btnMenuMainCourseThree.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseThree.TabIndex = 7;
            this.btnMenuMainCourseThree.UseSelectable = true;
            this.btnMenuMainCourseThree.Click += new System.EventHandler(this.btnMenuMainCourseThree_Click);
            // 
            // btnMenuMainCourseTwo
            // 
            this.btnMenuMainCourseTwo.Location = new System.Drawing.Point(355, 22);
            this.btnMenuMainCourseTwo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseTwo.Name = "btnMenuMainCourseTwo";
            this.btnMenuMainCourseTwo.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseTwo.TabIndex = 6;
            this.btnMenuMainCourseTwo.Text = "Chicken Sandwich";
            this.btnMenuMainCourseTwo.UseSelectable = true;
            this.btnMenuMainCourseTwo.Click += new System.EventHandler(this.btnMenuMainCourseTwo_Click);
            // 
            // btnMenuMainCourseOne
            // 
            this.btnMenuMainCourseOne.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnMenuMainCourseOne.Location = new System.Drawing.Point(20, 22);
            this.btnMenuMainCourseOne.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourseOne.Name = "btnMenuMainCourseOne";
            this.btnMenuMainCourseOne.Size = new System.Drawing.Size(267, 190);
            this.btnMenuMainCourseOne.TabIndex = 5;
            this.btnMenuMainCourseOne.Text = "Tuna Sandwich";
            this.btnMenuMainCourseOne.UseSelectable = true;
            this.btnMenuMainCourseOne.Click += new System.EventHandler(this.btnMenuMainCourseOne_Click);
            // 
            // tabDrinksPage
            // 
            this.tabDrinksPage.Controls.Add(this.btnMenuDrinksSeven);
            this.tabDrinksPage.Controls.Add(this.btnMenuDrinksFive);
            this.tabDrinksPage.Controls.Add(this.btnMenuDrinksFour);
            this.tabDrinksPage.Controls.Add(this.btnMenuDrinksThree);
            this.tabDrinksPage.Controls.Add(this.btnMenuDrinksTwo);
            this.tabDrinksPage.Controls.Add(this.btnMenuDrinksOne);
            this.tabDrinksPage.HorizontalScrollbarBarColor = true;
            this.tabDrinksPage.HorizontalScrollbarHighlightOnWheel = false;
            this.tabDrinksPage.HorizontalScrollbarSize = 12;
            this.tabDrinksPage.Location = new System.Drawing.Point(4, 38);
            this.tabDrinksPage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabDrinksPage.Name = "tabDrinksPage";
            this.tabDrinksPage.Size = new System.Drawing.Size(1313, 501);
            this.tabDrinksPage.TabIndex = 2;
            this.tabDrinksPage.VerticalScrollbarBarColor = true;
            this.tabDrinksPage.VerticalScrollbarHighlightOnWheel = false;
            this.tabDrinksPage.VerticalScrollbarSize = 13;
            // 
            // btnMenuDrinksSeven
            // 
            this.btnMenuDrinksSeven.Location = new System.Drawing.Point(355, 271);
            this.btnMenuDrinksSeven.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinksSeven.Name = "btnMenuDrinksSeven";
            this.btnMenuDrinksSeven.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDrinksSeven.TabIndex = 18;
            this.btnMenuDrinksSeven.Text = "Orange Juice";
            this.btnMenuDrinksSeven.UseSelectable = true;
            this.btnMenuDrinksSeven.Click += new System.EventHandler(this.btnMenuDrinksSeven_Click);
            // 
            // btnMenuDrinksFive
            // 
            this.btnMenuDrinksFive.Location = new System.Drawing.Point(20, 271);
            this.btnMenuDrinksFive.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinksFive.Name = "btnMenuDrinksFive";
            this.btnMenuDrinksFive.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDrinksFive.TabIndex = 17;
            this.btnMenuDrinksFive.Text = "Pipeapple Juice";
            this.btnMenuDrinksFive.UseSelectable = true;
            this.btnMenuDrinksFive.Click += new System.EventHandler(this.btnMenuDrinksFive_Click);
            // 
            // btnMenuDrinksFour
            // 
            this.btnMenuDrinksFour.Location = new System.Drawing.Point(1023, 22);
            this.btnMenuDrinksFour.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinksFour.Name = "btnMenuDrinksFour";
            this.btnMenuDrinksFour.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDrinksFour.TabIndex = 16;
            this.btnMenuDrinksFour.Text = "Mountain Dew";
            this.btnMenuDrinksFour.UseSelectable = true;
            this.btnMenuDrinksFour.Click += new System.EventHandler(this.btnMenuDrinksFour_Click);
            // 
            // btnMenuDrinksThree
            // 
            this.btnMenuDrinksThree.Location = new System.Drawing.Point(689, 22);
            this.btnMenuDrinksThree.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinksThree.Name = "btnMenuDrinksThree";
            this.btnMenuDrinksThree.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDrinksThree.TabIndex = 15;
            this.btnMenuDrinksThree.Text = "Fanta";
            this.btnMenuDrinksThree.UseSelectable = true;
            this.btnMenuDrinksThree.Click += new System.EventHandler(this.btnMenuDrinksThree_Click);
            // 
            // btnMenuDrinksTwo
            // 
            this.btnMenuDrinksTwo.Location = new System.Drawing.Point(355, 22);
            this.btnMenuDrinksTwo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinksTwo.Name = "btnMenuDrinksTwo";
            this.btnMenuDrinksTwo.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDrinksTwo.TabIndex = 14;
            this.btnMenuDrinksTwo.Text = "Sprite";
            this.btnMenuDrinksTwo.UseSelectable = true;
            this.btnMenuDrinksTwo.Click += new System.EventHandler(this.btnMenuDrinksTwo_Click);
            // 
            // btnMenuDrinksOne
            // 
            this.btnMenuDrinksOne.Location = new System.Drawing.Point(20, 22);
            this.btnMenuDrinksOne.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinksOne.Name = "btnMenuDrinksOne";
            this.btnMenuDrinksOne.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDrinksOne.TabIndex = 13;
            this.btnMenuDrinksOne.Text = "Coke";
            this.btnMenuDrinksOne.UseSelectable = true;
            this.btnMenuDrinksOne.Click += new System.EventHandler(this.btnMenuDrinksOne_Click);
            // 
            // tabDessertPage
            // 
            this.tabDessertPage.Controls.Add(this.btnMenuDessertFour);
            this.tabDessertPage.Controls.Add(this.btnMenuDessertThree);
            this.tabDessertPage.Controls.Add(this.btnMenuDessertTwo);
            this.tabDessertPage.Controls.Add(this.btnMenuDessertOne);
            this.tabDessertPage.HorizontalScrollbarBarColor = true;
            this.tabDessertPage.HorizontalScrollbarHighlightOnWheel = false;
            this.tabDessertPage.HorizontalScrollbarSize = 12;
            this.tabDessertPage.Location = new System.Drawing.Point(4, 38);
            this.tabDessertPage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabDessertPage.Name = "tabDessertPage";
            this.tabDessertPage.Size = new System.Drawing.Size(1313, 501);
            this.tabDessertPage.TabIndex = 3;
            this.tabDessertPage.VerticalScrollbarBarColor = true;
            this.tabDessertPage.VerticalScrollbarHighlightOnWheel = false;
            this.tabDessertPage.VerticalScrollbarSize = 13;
            // 
            // btnMenuDessertFour
            // 
            this.btnMenuDessertFour.Location = new System.Drawing.Point(1023, 22);
            this.btnMenuDessertFour.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDessertFour.Name = "btnMenuDessertFour";
            this.btnMenuDessertFour.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDessertFour.TabIndex = 22;
            this.btnMenuDessertFour.Text = "Churro Donut";
            this.btnMenuDessertFour.UseSelectable = true;
            this.btnMenuDessertFour.Click += new System.EventHandler(this.btnMenuDessertFour_Click);
            // 
            // btnMenuDessertThree
            // 
            this.btnMenuDessertThree.Location = new System.Drawing.Point(689, 22);
            this.btnMenuDessertThree.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDessertThree.Name = "btnMenuDessertThree";
            this.btnMenuDessertThree.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDessertThree.TabIndex = 21;
            this.btnMenuDessertThree.Tag = "";
            this.btnMenuDessertThree.Text = "Ube Cheese Pie";
            this.btnMenuDessertThree.UseSelectable = true;
            this.btnMenuDessertThree.Click += new System.EventHandler(this.btnMenuDessertThree_Click);
            // 
            // btnMenuDessertTwo
            // 
            this.btnMenuDessertTwo.Location = new System.Drawing.Point(355, 22);
            this.btnMenuDessertTwo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDessertTwo.Name = "btnMenuDessertTwo";
            this.btnMenuDessertTwo.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDessertTwo.TabIndex = 20;
            this.btnMenuDessertTwo.Text = "Leche Flan";
            this.btnMenuDessertTwo.UseSelectable = true;
            this.btnMenuDessertTwo.Click += new System.EventHandler(this.btnMenuDessertTwo_Click);
            // 
            // btnMenuDessertOne
            // 
            this.btnMenuDessertOne.Location = new System.Drawing.Point(20, 22);
            this.btnMenuDessertOne.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDessertOne.Name = "btnMenuDessertOne";
            this.btnMenuDessertOne.Size = new System.Drawing.Size(267, 190);
            this.btnMenuDessertOne.TabIndex = 19;
            this.btnMenuDessertOne.Text = "Halo Halo";
            this.btnMenuDessertOne.UseSelectable = true;
            this.btnMenuDessertOne.Click += new System.EventHandler(this.btnMenuDessertOne_Click);
            // 
            // tabFavoritesPage
            // 
            this.tabFavoritesPage.Controls.Add(this.btnMenuFavoritesFive);
            this.tabFavoritesPage.Controls.Add(this.btnMenuFavoritesFour);
            this.tabFavoritesPage.Controls.Add(this.btnMenuFavoritesThree);
            this.tabFavoritesPage.Controls.Add(this.btnMenuFavoritesTwo);
            this.tabFavoritesPage.Controls.Add(this.btnMenuFavoritesOne);
            this.tabFavoritesPage.HorizontalScrollbarBarColor = true;
            this.tabFavoritesPage.HorizontalScrollbarHighlightOnWheel = false;
            this.tabFavoritesPage.HorizontalScrollbarSize = 12;
            this.tabFavoritesPage.Location = new System.Drawing.Point(4, 38);
            this.tabFavoritesPage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabFavoritesPage.Name = "tabFavoritesPage";
            this.tabFavoritesPage.Size = new System.Drawing.Size(1313, 501);
            this.tabFavoritesPage.TabIndex = 4;
            this.tabFavoritesPage.VerticalScrollbarBarColor = true;
            this.tabFavoritesPage.VerticalScrollbarHighlightOnWheel = false;
            this.tabFavoritesPage.VerticalScrollbarSize = 13;
            // 
            // btnMenuFavoritesFive
            // 
            this.btnMenuFavoritesFive.Location = new System.Drawing.Point(20, 271);
            this.btnMenuFavoritesFive.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuFavoritesFive.Name = "btnMenuFavoritesFive";
            this.btnMenuFavoritesFive.Size = new System.Drawing.Size(267, 190);
            this.btnMenuFavoritesFive.TabIndex = 27;
            this.btnMenuFavoritesFive.UseSelectable = true;
            this.btnMenuFavoritesFive.Click += new System.EventHandler(this.btnMenuFavoritesFive_Click);
            // 
            // btnMenuFavoritesFour
            // 
            this.btnMenuFavoritesFour.Location = new System.Drawing.Point(1023, 22);
            this.btnMenuFavoritesFour.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuFavoritesFour.Name = "btnMenuFavoritesFour";
            this.btnMenuFavoritesFour.Size = new System.Drawing.Size(267, 190);
            this.btnMenuFavoritesFour.TabIndex = 26;
            this.btnMenuFavoritesFour.UseSelectable = true;
            this.btnMenuFavoritesFour.Click += new System.EventHandler(this.btnMenuFavoritesFour_Click);
            // 
            // btnMenuFavoritesThree
            // 
            this.btnMenuFavoritesThree.Location = new System.Drawing.Point(689, 22);
            this.btnMenuFavoritesThree.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuFavoritesThree.Name = "btnMenuFavoritesThree";
            this.btnMenuFavoritesThree.Size = new System.Drawing.Size(267, 190);
            this.btnMenuFavoritesThree.TabIndex = 25;
            this.btnMenuFavoritesThree.UseSelectable = true;
            this.btnMenuFavoritesThree.Click += new System.EventHandler(this.btnMenuFavoritesThree_Click);
            // 
            // btnMenuFavoritesTwo
            // 
            this.btnMenuFavoritesTwo.Location = new System.Drawing.Point(355, 22);
            this.btnMenuFavoritesTwo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuFavoritesTwo.Name = "btnMenuFavoritesTwo";
            this.btnMenuFavoritesTwo.Size = new System.Drawing.Size(267, 190);
            this.btnMenuFavoritesTwo.TabIndex = 24;
            this.btnMenuFavoritesTwo.UseSelectable = true;
            this.btnMenuFavoritesTwo.Click += new System.EventHandler(this.btnMenuFavoritesTwo_Click);
            // 
            // btnMenuFavoritesOne
            // 
            this.btnMenuFavoritesOne.Location = new System.Drawing.Point(20, 22);
            this.btnMenuFavoritesOne.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuFavoritesOne.Name = "btnMenuFavoritesOne";
            this.btnMenuFavoritesOne.Size = new System.Drawing.Size(267, 190);
            this.btnMenuFavoritesOne.TabIndex = 23;
            this.btnMenuFavoritesOne.UseSelectable = true;
            this.btnMenuFavoritesOne.Click += new System.EventHandler(this.btnMenuFavoritesOne_Click);
            // 
            // btnMenuDrinks
            // 
            this.btnMenuDrinks.Location = new System.Drawing.Point(373, 596);
            this.btnMenuDrinks.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDrinks.Name = "btnMenuDrinks";
            this.btnMenuDrinks.Size = new System.Drawing.Size(223, 63);
            this.btnMenuDrinks.TabIndex = 2;
            this.btnMenuDrinks.Text = "Drinks";
            this.btnMenuDrinks.UseSelectable = true;
            this.btnMenuDrinks.Click += new System.EventHandler(this.btnMenuDrinks_Click);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(1327, 236);
            this.metroLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(40, 20);
            this.metroLabel4.TabIndex = 6;
            this.metroLabel4.Text = "Total:";
            // 
            // btnMenuFavorites
            // 
            this.btnMenuFavorites.Location = new System.Drawing.Point(1044, 596);
            this.btnMenuFavorites.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuFavorites.Name = "btnMenuFavorites";
            this.btnMenuFavorites.Size = new System.Drawing.Size(223, 63);
            this.btnMenuFavorites.TabIndex = 4;
            this.btnMenuFavorites.Text = "Favorites";
            this.btnMenuFavorites.UseSelectable = true;
            this.btnMenuFavorites.Click += new System.EventHandler(this.btnMenuFavorites_Click);
            // 
            // btnMenuDessert
            // 
            this.btnMenuDessert.Location = new System.Drawing.Point(712, 596);
            this.btnMenuDessert.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuDessert.Name = "btnMenuDessert";
            this.btnMenuDessert.Size = new System.Drawing.Size(223, 63);
            this.btnMenuDessert.TabIndex = 3;
            this.btnMenuDessert.Text = "Dessert";
            this.btnMenuDessert.UseSelectable = true;
            this.btnMenuDessert.Click += new System.EventHandler(this.btnMenuDessert_Click);
            // 
            // txtMenuTotal
            // 
            // 
            // 
            // 
            this.txtMenuTotal.CustomButton.Image = null;
            this.txtMenuTotal.CustomButton.Location = new System.Drawing.Point(72, 2);
            this.txtMenuTotal.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtMenuTotal.CustomButton.Name = "";
            this.txtMenuTotal.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.txtMenuTotal.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtMenuTotal.CustomButton.TabIndex = 1;
            this.txtMenuTotal.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtMenuTotal.CustomButton.UseSelectable = true;
            this.txtMenuTotal.CustomButton.Visible = false;
            this.txtMenuTotal.Lines = new string[0];
            this.txtMenuTotal.Location = new System.Drawing.Point(1413, 231);
            this.txtMenuTotal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMenuTotal.MaxLength = 32767;
            this.txtMenuTotal.Name = "txtMenuTotal";
            this.txtMenuTotal.PasswordChar = '\0';
            this.txtMenuTotal.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtMenuTotal.SelectedText = "";
            this.txtMenuTotal.SelectionLength = 0;
            this.txtMenuTotal.SelectionStart = 0;
            this.txtMenuTotal.ShortcutsEnabled = true;
            this.txtMenuTotal.Size = new System.Drawing.Size(80, 28);
            this.txtMenuTotal.TabIndex = 5;
            this.txtMenuTotal.UseSelectable = true;
            this.txtMenuTotal.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtMenuTotal.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnMenuMainCourse
            // 
            this.btnMenuMainCourse.Location = new System.Drawing.Point(43, 596);
            this.btnMenuMainCourse.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuMainCourse.Name = "btnMenuMainCourse";
            this.btnMenuMainCourse.Size = new System.Drawing.Size(223, 63);
            this.btnMenuMainCourse.TabIndex = 1;
            this.btnMenuMainCourse.Text = "Main Course";
            this.btnMenuMainCourse.UseSelectable = true;
            this.btnMenuMainCourse.Click += new System.EventHandler(this.btnMenuMainCourse_Click);
            // 
            // txtMenuOrder
            // 
            // 
            // 
            // 
            this.txtMenuOrder.CustomButton.Image = null;
            this.txtMenuOrder.CustomButton.Location = new System.Drawing.Point(89, 1);
            this.txtMenuOrder.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtMenuOrder.CustomButton.Name = "";
            this.txtMenuOrder.CustomButton.Size = new System.Drawing.Size(244, 225);
            this.txtMenuOrder.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtMenuOrder.CustomButton.TabIndex = 1;
            this.txtMenuOrder.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtMenuOrder.CustomButton.UseSelectable = true;
            this.txtMenuOrder.CustomButton.Visible = false;
            this.txtMenuOrder.Lines = new string[0];
            this.txtMenuOrder.Location = new System.Drawing.Point(1412, 18);
            this.txtMenuOrder.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMenuOrder.MaxLength = 32767;
            this.txtMenuOrder.Name = "txtMenuOrder";
            this.txtMenuOrder.PasswordChar = '\0';
            this.txtMenuOrder.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtMenuOrder.SelectedText = "";
            this.txtMenuOrder.SelectionLength = 0;
            this.txtMenuOrder.SelectionStart = 0;
            this.txtMenuOrder.ShortcutsEnabled = true;
            this.txtMenuOrder.Size = new System.Drawing.Size(251, 185);
            this.txtMenuOrder.TabIndex = 3;
            this.txtMenuOrder.UseSelectable = true;
            this.txtMenuOrder.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtMenuOrder.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnMenuCheckOut
            // 
            this.btnMenuCheckOut.Location = new System.Drawing.Point(1412, 303);
            this.btnMenuCheckOut.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuCheckOut.Name = "btnMenuCheckOut";
            this.btnMenuCheckOut.Size = new System.Drawing.Size(241, 65);
            this.btnMenuCheckOut.TabIndex = 4;
            this.btnMenuCheckOut.Text = "Check Out";
            this.btnMenuCheckOut.UseSelectable = true;
            this.btnMenuCheckOut.Click += new System.EventHandler(this.btnMenuCheckOut_Click);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(1327, 18);
            this.metroLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(60, 20);
            this.metroLabel3.TabIndex = 2;
            this.metroLabel3.Text = "Order/s:";
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.dataSalesFood);
            this.metroTabPage2.Controls.Add(this.dataSalesCustomer);
            this.metroTabPage2.Controls.Add(this.btnSalesSearch);
            this.metroTabPage2.Controls.Add(this.txtSaleSearch);
            this.metroTabPage2.Controls.Add(this.dataSales);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 12;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 41);
            this.metroTabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(1683, 735);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "Sales";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 13;
            // 
            // dataSalesFood
            // 
            this.dataSalesFood.AllowUserToAddRows = false;
            this.dataSalesFood.AllowUserToDeleteRows = false;
            this.dataSalesFood.AllowUserToResizeRows = false;
            this.dataSalesFood.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataSalesFood.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataSalesFood.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataSalesFood.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSalesFood.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dataSalesFood.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataSalesFood.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16});
            this.dataSalesFood.Cursor = System.Windows.Forms.Cursors.No;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataSalesFood.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataSalesFood.EnableHeadersVisualStyles = false;
            this.dataSalesFood.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dataSalesFood.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataSalesFood.Location = new System.Drawing.Point(996, 389);
            this.dataSalesFood.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataSalesFood.Name = "dataSalesFood";
            this.dataSalesFood.ReadOnly = true;
            this.dataSalesFood.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSalesFood.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dataSalesFood.RowHeadersWidth = 51;
            this.dataSalesFood.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataSalesFood.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataSalesFood.Size = new System.Drawing.Size(645, 332);
            this.dataSalesFood.Style = MetroFramework.MetroColorStyle.Orange;
            this.dataSalesFood.TabIndex = 8;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "Column1";
            this.dataGridViewTextBoxColumn13.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 125;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.HeaderText = "Column2";
            this.dataGridViewTextBoxColumn14.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 125;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.HeaderText = "Column3";
            this.dataGridViewTextBoxColumn15.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 125;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.HeaderText = "Column4";
            this.dataGridViewTextBoxColumn16.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Width = 125;
            // 
            // dataSalesCustomer
            // 
            this.dataSalesCustomer.AllowUserToAddRows = false;
            this.dataSalesCustomer.AllowUserToDeleteRows = false;
            this.dataSalesCustomer.AllowUserToResizeRows = false;
            this.dataSalesCustomer.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataSalesCustomer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataSalesCustomer.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataSalesCustomer.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSalesCustomer.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dataSalesCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataSalesCustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.dataSalesCustomer.Cursor = System.Windows.Forms.Cursors.No;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataSalesCustomer.DefaultCellStyle = dataGridViewCellStyle17;
            this.dataSalesCustomer.EnableHeadersVisualStyles = false;
            this.dataSalesCustomer.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dataSalesCustomer.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataSalesCustomer.Location = new System.Drawing.Point(996, 41);
            this.dataSalesCustomer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataSalesCustomer.Name = "dataSalesCustomer";
            this.dataSalesCustomer.ReadOnly = true;
            this.dataSalesCustomer.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSalesCustomer.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dataSalesCustomer.RowHeadersWidth = 51;
            this.dataSalesCustomer.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataSalesCustomer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataSalesCustomer.Size = new System.Drawing.Size(645, 332);
            this.dataSalesCustomer.Style = MetroFramework.MetroColorStyle.Orange;
            this.dataSalesCustomer.TabIndex = 7;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "Column1";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 125;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "Column2";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 125;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "Column3";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 125;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "Column4";
            this.dataGridViewTextBoxColumn12.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 125;
            // 
            // btnSalesSearch
            // 
            this.btnSalesSearch.Location = new System.Drawing.Point(313, 4);
            this.btnSalesSearch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSalesSearch.Name = "btnSalesSearch";
            this.btnSalesSearch.Size = new System.Drawing.Size(127, 28);
            this.btnSalesSearch.TabIndex = 6;
            this.btnSalesSearch.Text = "SEARCH";
            this.btnSalesSearch.UseSelectable = true;
            // 
            // txtSaleSearch
            // 
            // 
            // 
            // 
            this.txtSaleSearch.CustomButton.Image = null;
            this.txtSaleSearch.CustomButton.Location = new System.Drawing.Point(1555, 2);
            this.txtSaleSearch.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtSaleSearch.CustomButton.Name = "";
            this.txtSaleSearch.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.txtSaleSearch.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSaleSearch.CustomButton.TabIndex = 1;
            this.txtSaleSearch.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSaleSearch.CustomButton.UseSelectable = true;
            this.txtSaleSearch.CustomButton.Visible = false;
            this.txtSaleSearch.Lines = new string[0];
            this.txtSaleSearch.Location = new System.Drawing.Point(449, 5);
            this.txtSaleSearch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSaleSearch.MaxLength = 32767;
            this.txtSaleSearch.Name = "txtSaleSearch";
            this.txtSaleSearch.PasswordChar = '\0';
            this.txtSaleSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSaleSearch.SelectedText = "";
            this.txtSaleSearch.SelectionLength = 0;
            this.txtSaleSearch.SelectionStart = 0;
            this.txtSaleSearch.ShortcutsEnabled = true;
            this.txtSaleSearch.Size = new System.Drawing.Size(1192, 28);
            this.txtSaleSearch.TabIndex = 5;
            this.txtSaleSearch.UseSelectable = true;
            this.txtSaleSearch.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSaleSearch.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // dataSales
            // 
            this.dataSales.AllowUserToAddRows = false;
            this.dataSales.AllowUserToDeleteRows = false;
            this.dataSales.AllowUserToResizeRows = false;
            this.dataSales.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataSales.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataSales.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataSales.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSales.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dataSales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataSales.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.dataSales.Cursor = System.Windows.Forms.Cursors.No;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataSales.DefaultCellStyle = dataGridViewCellStyle20;
            this.dataSales.EnableHeadersVisualStyles = false;
            this.dataSales.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dataSales.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataSales.Location = new System.Drawing.Point(312, 41);
            this.dataSales.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataSales.Name = "dataSales";
            this.dataSales.ReadOnly = true;
            this.dataSales.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSales.RowHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.dataSales.RowHeadersWidth = 51;
            this.dataSales.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataSales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataSales.Size = new System.Drawing.Size(649, 684);
            this.dataSales.Style = MetroFramework.MetroColorStyle.Orange;
            this.dataSales.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Column1";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Column2";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Column3";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Column4";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 125;
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.btnTransactionSearch);
            this.metroTabPage3.Controls.Add(this.txtTransactionSearch);
            this.metroTabPage3.Controls.Add(this.dataTransaction);
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.HorizontalScrollbarSize = 12;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 41);
            this.metroTabPage3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(1683, 735);
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Text = "Transaction History";
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            this.metroTabPage3.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.VerticalScrollbarSize = 13;
            // 
            // btnTransactionSearch
            // 
            this.btnTransactionSearch.Location = new System.Drawing.Point(5, 4);
            this.btnTransactionSearch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTransactionSearch.Name = "btnTransactionSearch";
            this.btnTransactionSearch.Size = new System.Drawing.Size(127, 28);
            this.btnTransactionSearch.TabIndex = 9;
            this.btnTransactionSearch.Text = "SEARCH";
            this.btnTransactionSearch.UseSelectable = true;
            // 
            // txtTransactionSearch
            // 
            // 
            // 
            // 
            this.txtTransactionSearch.CustomButton.Image = null;
            this.txtTransactionSearch.CustomButton.Location = new System.Drawing.Point(1521, 2);
            this.txtTransactionSearch.CustomButton.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtTransactionSearch.CustomButton.Name = "";
            this.txtTransactionSearch.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.txtTransactionSearch.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtTransactionSearch.CustomButton.TabIndex = 1;
            this.txtTransactionSearch.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtTransactionSearch.CustomButton.UseSelectable = true;
            this.txtTransactionSearch.CustomButton.Visible = false;
            this.txtTransactionSearch.Lines = new string[0];
            this.txtTransactionSearch.Location = new System.Drawing.Point(140, 5);
            this.txtTransactionSearch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTransactionSearch.MaxLength = 32767;
            this.txtTransactionSearch.Name = "txtTransactionSearch";
            this.txtTransactionSearch.PasswordChar = '\0';
            this.txtTransactionSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTransactionSearch.SelectedText = "";
            this.txtTransactionSearch.SelectionLength = 0;
            this.txtTransactionSearch.SelectionStart = 0;
            this.txtTransactionSearch.ShortcutsEnabled = true;
            this.txtTransactionSearch.Size = new System.Drawing.Size(1167, 28);
            this.txtTransactionSearch.TabIndex = 8;
            this.txtTransactionSearch.UseSelectable = true;
            this.txtTransactionSearch.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtTransactionSearch.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // dataTransaction
            // 
            this.dataTransaction.AllowUserToAddRows = false;
            this.dataTransaction.AllowUserToDeleteRows = false;
            this.dataTransaction.AllowUserToResizeRows = false;
            this.dataTransaction.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataTransaction.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataTransaction.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataTransaction.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataTransaction.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dataTransaction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataTransaction.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataTransaction.DefaultCellStyle = dataGridViewCellStyle23;
            this.dataTransaction.EnableHeadersVisualStyles = false;
            this.dataTransaction.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dataTransaction.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataTransaction.Location = new System.Drawing.Point(3, 41);
            this.dataTransaction.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataTransaction.Name = "dataTransaction";
            this.dataTransaction.ReadOnly = true;
            this.dataTransaction.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataTransaction.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.dataTransaction.RowHeadersWidth = 51;
            this.dataTransaction.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataTransaction.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataTransaction.Size = new System.Drawing.Size(1305, 684);
            this.dataTransaction.Style = MetroFramework.MetroColorStyle.Orange;
            this.dataTransaction.TabIndex = 7;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Column1";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Column2";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Column3";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Column4";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // metroDateTime1
            // 
            this.metroDateTime1.CausesValidation = false;
            this.metroDateTime1.Checked = false;
            this.metroDateTime1.Location = new System.Drawing.Point(1449, 52);
            this.metroDateTime1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroDateTime1.MinimumSize = new System.Drawing.Size(0, 30);
            this.metroDateTime1.Name = "metroDateTime1";
            this.metroDateTime1.Size = new System.Drawing.Size(265, 30);
            this.metroDateTime1.TabIndex = 1;
            this.metroDateTime1.TabStop = false;
            // 
            // frmHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(1751, 880);
            this.Controls.Add(this.metroDateTime1);
            this.Controls.Add(this.metroTabControl1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmHome";
            this.Padding = new System.Windows.Forms.Padding(27, 74, 27, 25);
            this.Style = MetroFramework.MetroColorStyle.Orange;
            this.Text = "Eats2Go";
            this.Load += new System.EventHandler(this.frmHome_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            this.tabMenuControl.ResumeLayout(false);
            this.tabMainCoursePage.ResumeLayout(false);
            this.tabDrinksPage.ResumeLayout(false);
            this.tabDessertPage.ResumeLayout(false);
            this.tabFavoritesPage.ResumeLayout(false);
            this.metroTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataSalesFood)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSalesCustomer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSales)).EndInit();
            this.metroTabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataTransaction)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private MetroFramework.Controls.MetroGrid dataSales;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private MetroFramework.Controls.MetroButton btnSalesSearch;
        private MetroFramework.Controls.MetroTextBox txtSaleSearch;
        private MetroFramework.Controls.MetroButton btnTransactionSearch;
        private MetroFramework.Controls.MetroTextBox txtTransactionSearch;
        private MetroFramework.Controls.MetroGrid dataTransaction;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private MetroFramework.Controls.MetroDateTime metroDateTime1;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTabControl tabMenuControl;
        private MetroFramework.Controls.MetroTabPage tabMainCoursePage;
        private MetroFramework.Controls.MetroTabPage tabDrinksPage;
        private MetroFramework.Controls.MetroTabPage tabDessertPage;
        private MetroFramework.Controls.MetroTabPage tabFavoritesPage;
        private MetroFramework.Controls.MetroButton btnMenuFavorites;
        private MetroFramework.Controls.MetroButton btnMenuDessert;
        private MetroFramework.Controls.MetroButton btnMenuMainCourse;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseFour;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseThree;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseTwo;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseOne;
        private MetroFramework.Controls.MetroButton btnMenuDrinksSeven;
        private MetroFramework.Controls.MetroButton btnMenuDrinksFive;
        private MetroFramework.Controls.MetroButton btnMenuDrinksFour;
        private MetroFramework.Controls.MetroButton btnMenuDrinksThree;
        private MetroFramework.Controls.MetroButton btnMenuDrinksTwo;
        private MetroFramework.Controls.MetroButton btnMenuDrinksOne;
        private MetroFramework.Controls.MetroButton btnMenuDessertFour;
        private MetroFramework.Controls.MetroButton btnMenuDessertThree;
        private MetroFramework.Controls.MetroButton btnMenuDessertTwo;
        private MetroFramework.Controls.MetroButton btnMenuDessertOne;
        private MetroFramework.Controls.MetroButton btnMenuFavoritesFive;
        private MetroFramework.Controls.MetroButton btnMenuFavoritesFour;
        private MetroFramework.Controls.MetroButton btnMenuFavoritesThree;
        private MetroFramework.Controls.MetroButton btnMenuFavoritesTwo;
        private MetroFramework.Controls.MetroButton btnMenuFavoritesOne;
        private MetroFramework.Controls.MetroButton btnMenuDrinks;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseEight;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseSeven;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseSix;
        private MetroFramework.Controls.MetroButton btnMenuMainCourseFive;
        private MetroFramework.Controls.MetroGrid dataSalesFood;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private MetroFramework.Controls.MetroGrid dataSalesCustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox txtMenuOrder;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroTextBox txtMenuTotal;
        private MetroFramework.Controls.MetroButton btnMenuCheckOut;
        private MetroFramework.Controls.MetroButton btnMenuCancel;
    }
}


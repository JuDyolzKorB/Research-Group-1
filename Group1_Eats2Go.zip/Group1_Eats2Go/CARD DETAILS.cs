﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace Group1_Eats2Go
{
    public partial class CARD_DETAILS : MetroForm
    {
        public CARD_DETAILS()
        {
            InitializeComponent();
        }

        private void CARD_DETAILS_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cardnumtxtdtl.Text.Length == 16)
            {
                MessageBox.Show("16-digit number confirmed.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("Please enter exactly 16 digits.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void cardnumtxtdtl_TextChanged(object sender, EventArgs e)
        {
            string input = cardnumtxtdtl.Text;
            if (!input.All(char.IsDigit))
            {
                MessageBox.Show("Only numeric values are allowed.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cardnumtxtdtl.Text = string.Concat(input.Where(char.IsDigit));
                cardnumtxtdtl.SelectionStart = cardnumtxtdtl.Text.Length; 
            }
        }
    }
}

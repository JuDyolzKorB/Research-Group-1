﻿namespace Group1_Eats2Go
{
    partial class frmMenuQuantity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtMenuQuantity = new MetroFramework.Controls.MetroTextBox();
            this.btnMenuQuantityAdd = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(5, 50);
            this.metroLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(64, 20);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "Quantity:";
            // 
            // txtMenuQuantity
            // 
            // 
            // 
            // 
            this.txtMenuQuantity.CustomButton.Image = null;
            this.txtMenuQuantity.CustomButton.Location = new System.Drawing.Point(124, 2);
            this.txtMenuQuantity.CustomButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMenuQuantity.CustomButton.Name = "";
            this.txtMenuQuantity.CustomButton.Size = new System.Drawing.Size(31, 28);
            this.txtMenuQuantity.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtMenuQuantity.CustomButton.TabIndex = 1;
            this.txtMenuQuantity.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtMenuQuantity.CustomButton.UseSelectable = true;
            this.txtMenuQuantity.CustomButton.Visible = false;
            this.txtMenuQuantity.Lines = new string[0];
            this.txtMenuQuantity.Location = new System.Drawing.Point(95, 50);
            this.txtMenuQuantity.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMenuQuantity.MaxLength = 32767;
            this.txtMenuQuantity.Name = "txtMenuQuantity";
            this.txtMenuQuantity.PasswordChar = '\0';
            this.txtMenuQuantity.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtMenuQuantity.SelectedText = "";
            this.txtMenuQuantity.SelectionLength = 0;
            this.txtMenuQuantity.SelectionStart = 0;
            this.txtMenuQuantity.ShortcutsEnabled = true;
            this.txtMenuQuantity.Size = new System.Drawing.Size(119, 28);
            this.txtMenuQuantity.TabIndex = 1;
            this.txtMenuQuantity.UseSelectable = true;
            this.txtMenuQuantity.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtMenuQuantity.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnMenuQuantityAdd
            // 
            this.btnMenuQuantityAdd.Location = new System.Drawing.Point(223, 49);
            this.btnMenuQuantityAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenuQuantityAdd.Name = "btnMenuQuantityAdd";
            this.btnMenuQuantityAdd.Size = new System.Drawing.Size(76, 28);
            this.btnMenuQuantityAdd.TabIndex = 2;
            this.btnMenuQuantityAdd.Text = "ADD";
            this.btnMenuQuantityAdd.UseSelectable = true;
            this.btnMenuQuantityAdd.Click += new System.EventHandler(this.btnMenuQuantityAdd_Click);
            // 
            // frmMenuQuantity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(309, 94);
            this.Controls.Add(this.btnMenuQuantityAdd);
            this.Controls.Add(this.txtMenuQuantity);
            this.Controls.Add(this.metroLabel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmMenuQuantity";
            this.Padding = new System.Windows.Forms.Padding(27, 74, 27, 25);
            this.Style = MetroFramework.MetroColorStyle.Orange;
            this.Load += new System.EventHandler(this.frmMenuQuantity_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox txtMenuQuantity;
        private MetroFramework.Controls.MetroButton btnMenuQuantityAdd;
    }
}